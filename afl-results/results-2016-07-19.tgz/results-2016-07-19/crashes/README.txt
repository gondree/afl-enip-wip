Command line used to find this crash:

/home/student/afl-2.19b/afl-fuzz -i /home/student/samples -o /home/student/results /home/student/OpENer/bin/posix/src/ports/POSIX/OpENer 10.0.2.15 255.255.255.0 10.0.2.1 test.com testdevice 00 15 C5 BF D0 87

If you can't reproduce a bug outside of afl-fuzz, be sure to set the same
memory limit. The limit used for this fuzzing session was 50.0 MB.

Need a tool to minimize test cases before investigating the crashes or sending
them to a vendor? Check out the afl-tmin that comes with the fuzzer!

Found any cool bugs in open-source tools using afl-fuzz? If yes, please drop
me a mail at <lcamtuf@coredump.cx> once the issues are fixed - I'd love to
add your finds to the gallery at:

  http://lcamtuf.coredump.cx/afl/

Thanks :-)
